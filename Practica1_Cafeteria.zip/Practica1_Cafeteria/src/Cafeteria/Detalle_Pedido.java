package Cafeteria;

public class Detalle_Pedido {
    private Producto producto;
    private int cantidad;
    private double precio;

    // Constructor para un pedido nuevo: toma el precio actual del producto
    public Detalle_Pedido(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.precio = producto.getPrecio();
    }

    // Constructor para cuando se lee del archivo: el precio viene guardado
    public Detalle_Pedido(Producto producto, int cantidad, double precio) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public double getPrecio() { return precio; }

    public double getSubtotal() {
        return precio * cantidad;
    }
}