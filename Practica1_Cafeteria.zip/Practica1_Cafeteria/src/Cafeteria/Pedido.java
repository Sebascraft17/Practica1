package Cafeteria;

import java.util.ArrayList;

public class Pedido {
    private int numero;
    private String fecha;
    private ArrayList<Detalle_Pedido> detalles;

    public Pedido(int numero, String fecha) {
        this.numero = numero;
        this.fecha = fecha;
        this.detalles = new ArrayList<>();
    }

    public int getNumero() { return numero; }
    public String getFecha() { return fecha; }
    public ArrayList<Detalle_Pedido> getDetalles() { return detalles; }

    public void agregarDetalle(Detalle_Pedido detalle) {
        detalles.add(detalle);
    }

    // Genérico: agrega un producto al pedido si la cantidad es válida y hay stock
    public <T extends Number> boolean agregarProducto(Producto producto, T cantidad) {
        int unidades = cantidad.intValue();
        if (unidades <= 0 || !producto.hayStock(unidades)) {
            return false;
        }
        producto.disminuirStock(unidades);
        detalles.add(new Detalle_Pedido(producto, unidades));
        return true;
    }

    // Suma el subtotal de cada detalle
    public double getTotal() {
        double total = 0;
        for (Detalle_Pedido d : detalles) {
            total = total + d.getSubtotal();
        }
        return total;
    }
}