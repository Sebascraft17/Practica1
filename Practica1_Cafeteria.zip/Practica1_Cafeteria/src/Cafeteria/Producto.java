package Cafeteria;

public class Producto {
    private String codigo;
    private String nombre;
    private double precio;
    private int stock;

    public Producto(String codigo, String nombre, double precio, int stock) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public int getStock() { return stock; }

    // Genérico: acepta cualquier número (Integer, Double, etc.)
    public <T extends Number> void aumentarStock(T cantidad) {
        stock = stock + cantidad.intValue();
    }

    // Genérico: resta unidades al stock (venta)
    public <T extends Number> void disminuirStock(T cantidad) {
        stock = stock - cantidad.intValue();
    }

    // Genérico: dice si alcanza el stock para esa cantidad
    public <T extends Number> boolean hayStock(T cantidad) {
        return stock >= cantidad.intValue();
    }
}