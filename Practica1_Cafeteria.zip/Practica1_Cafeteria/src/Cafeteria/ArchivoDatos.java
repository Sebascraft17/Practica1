package Cafeteria;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ArchivoDatos {

    private String archivoProductos = "productos.txt";
    private String archivoPedidos = "pedidos.txt";

    // Cada línea: codigo nombre precio stock
    public void guardarProductos(ArrayList<Producto> lista) throws IOException {
        FileWriter escritor = new FileWriter(archivoProductos);
        for (Producto p : lista) {
            escritor.write(p.getCodigo() + " " + p.getNombre() + " " + p.getPrecio() + " " + p.getStock() + "\n");
        }
        escritor.close();
    }

    public ArrayList<Producto> cargarProductos() throws IOException {
        ArrayList<Producto> lista = new ArrayList<>();
        File archivo = new File(archivoProductos);
        if (archivo.exists()) {
            Scanner lector = new Scanner(archivo);
            while (lector.hasNext()) {
                String codigo = lector.next();
                String nombre = lector.next();
                double precio = Double.parseDouble(lector.next());
                int stock = lector.nextInt();
                lista.add(new Producto(codigo, nombre, precio, stock));
            }
            lector.close();
        }
        return lista;
    }

    public void guardarPedidos(ArrayList<Pedido> lista) throws IOException {
        FileWriter escritor = new FileWriter(archivoPedidos);
        for (Pedido pedido : lista) {
            for (Detalle_Pedido d : pedido.getDetalles()) {
                escritor.write(pedido.getNumero() + " " + pedido.getFecha() + " "
                        + d.getProducto().getCodigo() + " " + d.getCantidad() + " " + d.getPrecio() + "\n");
            }
        }
        escritor.close();
    }

    public ArrayList<Pedido> cargarPedidos(ArrayList<Producto> productos) throws IOException {
        ArrayList<Pedido> lista = new ArrayList<>();
        File archivo = new File(archivoPedidos);
        if (archivo.exists()) {
            Scanner lector = new Scanner(archivo);
            Pedido actual = null;
            while (lector.hasNext()) {
                int numero = lector.nextInt();
                String fecha = lector.next();
                String codigo = lector.next();
                int cantidad = lector.nextInt();
                double precio = Double.parseDouble(lector.next());

                // Si cambia el número de pedido, empieza un pedido nuevo
                if (actual == null || actual.getNumero() != numero) {
                    actual = new Pedido(numero, fecha);
                    lista.add(actual);
                }

                // Busca el producto de esta línea y agrega el detalle
                for (Producto p : productos) {
                    if (p.getCodigo().equals(codigo)) {
                        actual.agregarDetalle(new Detalle_Pedido(p, cantidad, precio));
                    }
                }
            }
            lector.close();
        }
        return lista;
    }
}