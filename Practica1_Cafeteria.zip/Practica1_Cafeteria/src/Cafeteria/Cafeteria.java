package Cafeteria;

import java.io.IOException;
import java.util.ArrayList;

public class Cafeteria {

    private ArrayList<Producto> productos;
    private ArrayList<Pedido> pedidos;
    private ArchivoDatos archivos;

    // Al crearse, carga los datos guardados (primero productos, después pedidos)
    public Cafeteria() throws IOException {
        archivos = new ArchivoDatos();
        productos = archivos.cargarProductos();
        pedidos = archivos.cargarPedidos(productos);
    }

    // Devuelve el producto con ese código, o null si no existe
    public Producto buscarProducto(String codigo) {
        for (Producto p : productos) {
            if (p.getCodigo().equals(codigo)) {
                return p;
            }
        }
        return null;
    }

    // Devuelve false si ya existe un producto con ese código
    public boolean registrarProducto(Producto producto) throws IOException {
        if (buscarProducto(producto.getCodigo()) != null) {
            return false;
        }
        productos.add(producto);
        archivos.guardarProductos(productos);
        return true;
    }

    public void listarProductos() {
        if (productos.isEmpty()) {
            System.out.println("El catálogo está vacío.");
        }
        for (Producto p : productos) {
            System.out.println(p.getCodigo() + " | " + p.getNombre() + " | $" + p.getPrecio() + " | Stock: " + p.getStock());
        }
    }

    // Devuelve false si el producto no existe
    public boolean reponerStock(String codigo, int cantidad) throws IOException {
        Producto p = buscarProducto(codigo);
        if (p == null) {
            return false;
        }
        p.aumentarStock(cantidad);
        archivos.guardarProductos(productos);
        return true;
    }

    public int siguienteNumeroPedido() {
        return pedidos.size() + 1;
    }

    // Guarda el pedido y el stock ya descontado
    public void registrarPedido(Pedido pedido) throws IOException {
        pedidos.add(pedido);
        archivos.guardarProductos(productos);
        archivos.guardarPedidos(pedidos);
    }

    public void reporteVentas(String fecha) {
        double total = 0;
        for (Pedido p : pedidos) {
            if (p.getFecha().equals(fecha)) {
                total = total + p.getTotal();
            }
        }
        System.out.println("Total vendido hoy: $" + total);

        Producto masVendido = null;
        int maximo = 0;
        for (Producto prod : productos) {
            int unidades = unidadesVendidas(prod, fecha);
            if (unidades > maximo) {
                maximo = unidades;
                masVendido = prod;
            }
        }
        if (masVendido != null) {
            System.out.println("Producto más vendido: " + masVendido.getNombre() + " (" + maximo + " unidades)");
        }
    }

    // Cuenta las unidades vendidas de un producto en esa fecha
    private int unidadesVendidas(Producto producto, String fecha) {
        int unidades = 0;
        for (Pedido p : pedidos) {
            if (p.getFecha().equals(fecha)) {
                for (Detalle_Pedido d : p.getDetalles()) {
                    if (d.getProducto().getCodigo().equals(producto.getCodigo())) {
                        unidades = unidades + d.getCantidad();
                    }
                }
            }
        }
        return unidades;
    }
}