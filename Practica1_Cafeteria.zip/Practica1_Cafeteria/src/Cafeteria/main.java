package Cafeteria;

import java.io.IOException;
import java.util.Scanner;

public class main {

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        Cafeteria cafeteria = new Cafeteria();

        System.out.print("Fecha de hoy (ejemplo 18/10/2026): ");
        String fecha = sc.next();
        String opcion;

        do {
            System.out.println("\n===== CAFETERÍA EL BUEN SABOR =====");
            System.out.println("1. Registrar producto");
            System.out.println("2. Listar productos");
            System.out.println("3. Reponer stock");
            System.out.println("4. Registrar pedido");
            System.out.println("5. Reporte de ventas");
            System.out.println("6. Salir");
            System.out.print("Elija una opción: ");
            opcion = sc.next();

            if (opcion.equals("1")) {
                System.out.print("Código: ");
                String codigo = sc.next().toUpperCase();
                if (cafeteria.buscarProducto(codigo) != null) {
                    System.out.println("Ya existe un producto con ese código.");
                } else {
                    System.out.print("Nombre (una sola palabra): ");
                    String nombre = sc.next();
                    System.out.print("Precio: ");
                    double precio = Double.parseDouble(sc.next());
                    System.out.print("Stock: ");
                    int stock = Integer.parseInt(sc.next());
                    cafeteria.registrarProducto(new Producto(codigo, nombre, precio, stock));
                    System.out.println("Producto registrado.");
                }

            } else if (opcion.equals("2")) {
                cafeteria.listarProductos();

            } else if (opcion.equals("3")) {
                System.out.print("Código del producto: ");
                String codigo = sc.next().toUpperCase();
                System.out.print("Cantidad a reponer: ");
                int cantidad = Integer.parseInt(sc.next());
                if (cafeteria.reponerStock(codigo, cantidad)) {
                    System.out.println("Stock actualizado.");
                } else {
                    System.out.println("No existe un producto con ese código.");
                }

            } else if (opcion.equals("4")) {
                Pedido pedido = new Pedido(cafeteria.siguienteNumeroPedido(), fecha);
                String codigo;

                do {
                    System.out.print("Código del producto (0 para terminar): ");
                    codigo = sc.next().toUpperCase();
                    if (!codigo.equals("0")) {
                        Producto p = cafeteria.buscarProducto(codigo);
                        if (p == null) {
                            System.out.println("No existe un producto con ese código.");
                        } else {
                            System.out.print("Cantidad: ");
                            int cantidad = Integer.parseInt(sc.next());
                            if (pedido.agregarProducto(p, cantidad)) {
                                System.out.println("Producto agregado.");
                            } else {
                                System.out.println("Cantidad no válida o stock insuficiente.");
                            }
                        }
                    }
                } while (!codigo.equals("0"));

                if (pedido.getDetalles().isEmpty()) {
                    System.out.println("El pedido está vacío. No se guardó.");
                } else {
                    cafeteria.registrarPedido(pedido);
                    System.out.println("\n--- PEDIDO N.º " + pedido.getNumero() + " ---");
                    for (Detalle_Pedido d : pedido.getDetalles()) {
                        System.out.println(d.getProducto().getNombre() + " x" + d.getCantidad()
                                + " ........ " + d.getSubtotal());
                    }
                    System.out.println("TOTAL A PAGAR: " + pedido.getTotal());
                }

            } else if (opcion.equals("5")) {
                cafeteria.reporteVentas(fecha);

            } else if (opcion.equals("6")) {
                System.out.println("Hasta pronto.");

            } else {
                System.out.println("Opción no válida.");
            }

        } while (!opcion.equals("6"));

        sc.close();
    }
}