package parqueadero;

public class vehiculo {
	private String placa;
	private String horaIngreso;
	private String horaSalida;
	private double valorPagar;
	
	public vehiculo(String placa, String horaIngreso) {
		this.placa= placa;
		this.horaIngreso= horaIngreso;
		this.horaSalida= "";
		this.valorPagar= 0.0;
	}

	public String getHoraSalida() {
		return horaSalida;
	}

	public double getValorPagar() {
		return valorPagar;
	}

	public String getPlaca() {
		return placa;
	}

	public String getHoraIngreso() {
		return horaIngreso;
	}
	
	public void setHoraSalida(String horaSalida) {
		this.horaSalida = horaSalida;
	}
	public void setValorPagar(double valorPagar) {
		this.valorPagar = valorPagar;
	}
	public String informacion() {
	    String salida = horaSalida;
	    if (salida.equals("")) {
	        salida = "Dentro";  
	    }
	    return "Placa: " + placa + " | Ingreso: " + horaIngreso
	         + " | Salida: " + salida + " | Valor: $" + String.format("%.2f", valorPagar);
	}
}
