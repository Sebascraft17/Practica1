package parqueadero;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Parqueadero {

    private ArrayList<vehiculo> vehiculos = new ArrayList<>();
    private double tarifa = 0.50;  

    public Parqueadero() throws IOException {
        File archivo = new File("vehiculos.txt");
        if (archivo.exists()) {
            Scanner lector = new Scanner(archivo);
            while (lector.hasNext()) {
                String placa = lector.next();
                String horaIngreso = lector.next();
                String horaSalida = lector.next();
                double valor = Double.parseDouble(lector.next());

                vehiculo v = new vehiculo(placa, horaIngreso);
                if (!horaSalida.equals("-")) {   
                    v.setHoraSalida(horaSalida);
                }
                v.setValorPagar(valor);
                vehiculos.add(v);
            }
            lector.close();
        }
    }

    private void guardar() throws IOException {
        FileWriter escritor = new FileWriter("vehiculos.txt");
        for (vehiculo v : vehiculos) {
            String salida = v.getHoraSalida();
            if (salida.equals("")) {
                salida = "-";
            }
            escritor.write(v.getPlaca() + " " + v.getHoraIngreso() + " " + salida + " " + v.getValorPagar() + "\n");
        }
        escritor.close();
    }

    private vehiculo buscarDentro(String placa) {
        for (vehiculo v : vehiculos) {
            if (v.getPlaca().equals(placa) && v.getHoraSalida().equals("")) {
                return v;
            }
        }
        return null;
    }

    private int aMinutos(String hora) {
        String[] partes = hora.split(":");
        return Integer.parseInt(partes[0]) * 60 + Integer.parseInt(partes[1]);
    }

    public boolean ingresar(String placa, String horaIngreso) throws IOException {
        if (buscarDentro(placa) != null) {
            return false;
        }
        vehiculos.add(new vehiculo(placa, horaIngreso));
        guardar();
        return true;
    }

    public double salir(String placa, String horaSalida) throws IOException {
        vehiculo v = buscarDentro(placa);
        if (v == null) {
            return -1;
        }

        int minutos = aMinutos(horaSalida) - aMinutos(v.getHoraIngreso());
        if (minutos < 0) {
            return -2;
        }

        int horas = minutos / 60;
        if (minutos % 60 != 0 || horas == 0) {
            horas++;   
        }
        double valor = horas * tarifa;

        v.setHoraSalida(horaSalida);
        v.setValorPagar(valor);
        guardar();

        FileWriter caja = new FileWriter("caja.txt", true);  
        caja.write(placa + " " + valor + "\n");
        caja.close();
        return valor;
    }

    public void mostrar() {
        if (vehiculos.isEmpty()) {
            System.out.println("No hay vehículos registrados.");
        }
        for (vehiculo v : vehiculos) {
            System.out.println(v.informacion());
        }
    }
    
    public String listado() {
        if (vehiculos.isEmpty()) {
            return "No hay vehículos registrados.";
        }
        String texto = "";
        for (vehiculo v : vehiculos) {
            texto = texto + v.informacion() + "\n";
        }
        return texto;
    }

    public double totalCaja() throws IOException {
        double total = 0;
        File archivo = new File("caja.txt");
        if (archivo.exists()) {
            Scanner lector = new Scanner(archivo);
            while (lector.hasNext()) {
                lector.next();                                        
                total = total + Double.parseDouble(lector.next());   
            }
            lector.close();
        }
        return total;
    }
}