package parqueadero;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class VentanaDiseño extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtPlaca;
	private JTextField txtHora;
	private JButton btnIngreso;
	private JButton btnSalida;
	private JButton btnCaja;
	private JLabel lblMensaje;
	private JTextArea areaListado;
	private Parqueadero parqueadero;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaDiseño frame = new VentanaDiseño();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public VentanaDiseño() throws IOException {
		parqueadero = new Parqueadero();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 772, 449);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Placa:");
		lblNewLabel.setBounds(28, 39, 44, 12);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Hora:");
		lblNewLabel_1.setBounds(28, 61, 44, 12);
		contentPane.add(lblNewLabel_1);

		txtPlaca = new JTextField();
		txtPlaca.setBounds(98, 36, 96, 18);
		contentPane.add(txtPlaca);
		txtPlaca.setColumns(10);

		txtHora = new JTextField();
		txtHora.setBounds(98, 58, 96, 18);
		contentPane.add(txtHora);
		txtHora.setColumns(10);

		btnIngreso = new JButton("Registrar ingreso");
		btnIngreso.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				registrarIngreso();
			}
		});
		btnIngreso.setBounds(27, 111, 115, 20);
		contentPane.add(btnIngreso);

		btnSalida = new JButton("Registrar salida");
		btnSalida.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				registrarSalida();
			}
		});
		btnSalida.setBounds(106, 142, 115, 20);
		contentPane.add(btnSalida);

		btnCaja = new JButton("Ver total de caja");
		btnCaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				verCaja();
			}
		});
		btnCaja.setBounds(182, 111, 115, 20);
		contentPane.add(btnCaja);

		lblMensaje = new JLabel("Escriba la hora como HH:mm (ej. 08:30)");
		lblMensaje.setBounds(28, 204, 310, 30);
		contentPane.add(lblMensaje);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(353, 39, 360, 174);
		contentPane.add(scrollPane);

		areaListado = new JTextArea();
		areaListado.setEditable(false);
		scrollPane.setViewportView(areaListado);

		areaListado.setText(parqueadero.listado());
	}

	private boolean horaValida(String hora) {
		return hora.matches("([01]\\d|2[0-3]):[0-5]\\d");
	}

	private void registrarIngreso() {
		String placa = txtPlaca.getText().trim().toUpperCase();
		String hora = txtHora.getText().trim();

		try {
			if (placa.equals("") || !horaValida(hora)) {
				lblMensaje.setText("Escriba la placa y la hora con formato HH:mm (ej. 08:30)");
			} else if (parqueadero.ingresar(placa, hora)) {
				lblMensaje.setText("Ingreso registrado: " + placa);
				txtPlaca.setText("");
				txtHora.setText("");
			} else {
				lblMensaje.setText("Ese vehículo ya está dentro.");
			}
		} catch (IOException ex) {
			lblMensaje.setText("Error al leer o escribir los archivos.");
		}
		areaListado.setText(parqueadero.listado());
	}

	private void registrarSalida() {
		String placa = txtPlaca.getText().trim().toUpperCase();
		String hora = txtHora.getText().trim();

		try {
			if (placa.equals("") || !horaValida(hora)) {
				lblMensaje.setText("Escriba la placa y la hora con formato HH:mm (ej. 10:15)");
			} else {
				double valor = parqueadero.salir(placa, hora);
				if (valor == -1) {
					lblMensaje.setText("No hay un vehículo con esa placa dentro.");
				} else if (valor == -2) {
					lblMensaje.setText("La salida no puede ser antes del ingreso.");
				} else {
					lblMensaje.setText("Valor a cancelar: $" + String.format("%.2f", valor));
					txtPlaca.setText("");
					txtHora.setText("");
				}
			}
		} catch (IOException ex) {
			lblMensaje.setText("Error al leer o escribir los archivos.");
		}
		areaListado.setText(parqueadero.listado());
	}

	private void verCaja() {
		try {
			lblMensaje.setText("Total en caja: $" + String.format("%.2f", parqueadero.totalCaja()));
		} catch (IOException ex) {
			lblMensaje.setText("Error al leer el archivo de caja.");
		}
	}
}