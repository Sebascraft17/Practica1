package parqueadero;

import java.io.IOException;

public class main {

    public static void main(String[] args) throws IOException {
        VentanaDiseño ventana = new VentanaDiseño();
        ventana.setVisible(true);
    }
}